#!/bin/bash
##------------- Di Coding Oleh Rizky Arif Nur Choir -------------##
#	CodeName	| AICD											  #
#	Version		| 0.1 Beta										  #
#	Release		| 14-03-2017									  #
#----------------------------------------------------------------##
awal(){
	siapa=`whoami`
	if [[ $siapa != "root" ]]; then
		echo "anda bukan root"
	else
		{ 
	 		for (( i = 0; i <= 100; i+=20 )); do
	 		sleep 1
	 		echo "$i"
	 		done 
	 	} | whiptail --backtitle "AICD 0.1 BETA" --title "Loading" --gauge "Sedang Menginstall CMS :" 10 40 0
	 	cp CMS/DesaKu.zip /var/www/html/
	 	diraw=`pwd`
	 	cd /var/www/html/
	 	unzip DesaKu.zip
	 	chown -R www-data:www-data DesaKu
	 	chmod -R 755 DesaKu
	 	pass=$(whiptail --backtitle "Pemasukan Password" --title "Sistem installasi CMS" --inputbox "Masukan password untuk user root database" 10 30 3>&1 1>&2 2>&3)
	 	input=$(whiptail --backtitle "Penamaan database" --title "Sistem installasi CMS" --inputbox "Masukan nama database" 10 30 3>&1 1>&2 2>&3)
	 	mysql -u root -p$pass -e "CREATE DATABASE $input ;" 2> /dev/null
	 	if [[ $? -eq "0" ]]; then
	 		mysql -u root -p$pass $input < DesaKu/database/desaku.sql
	 		us=$(whiptail --backtitle "Pemasukan Username login admin" --title "Sistem installasi CMS" --inputbox "Masukan Username untuk login admin" 10 30 3>&1 1>&2 2>&3)
	 		pss=$(whiptail --backtitle "Pemasukan Password login admin" --title "Sistem installasi CMS" --inputbox "Masukan Password untuk login admin" 10 30 3>&1 1>&2 2>&3)
	 		mysql -u root -p$pass -e "USE $input ; INSERT INTO admin VALUES (NULL , '$us' , MD5('$pss'));"
	 		rm -rf DesaKu/config/koneksi.php > /dev/null
	 		cp DesaKu/config.koneksi.php DesaKu/config/koneksi.php
	 		sed -i 's,password,'"$pass"',g' DesaKu/config/koneksi.php
	 		sed -i 's,desaku,'"$input"',g' DesaKu/config/koneksi.php
	 		#echo -e "<?php \n header('location:Home'); \n exit(); \n ?>" > DesaKu/index.php
	 	else
	 		readarray -t newtcols < /etc/newt/palette
			newtcols_error=(
 			  root=,red 
			   button=white,red
			)

			NEWT_COLORS="${newtcols[@]} ${newtcols_error[@]}" \
			whiptail --backtitle "Gagal Membuat Database" --title "Kesalahan" --msgbox "Gagal Membuat Database silahkan cek password dan database anda" 10 40
			rm -rf DesaKu
			rm -rf DesaKu.zip
	 	fi

	fi
}
awal